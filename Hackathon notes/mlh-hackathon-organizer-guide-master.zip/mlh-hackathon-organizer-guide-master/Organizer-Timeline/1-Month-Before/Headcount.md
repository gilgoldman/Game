### Get Final Headcount

Work to confirm a solid headcount. Having this will help you when making food and swag orders. Generally, events see a 30-50% attrition rate, so make sure you consider this in your planning.  Make a plan for what to do if you have more sign ups than your event is being planned for.  If you exceed your initial goals you might need to make a waitlist.  Try to give priority to hackers who are closer to your event since they are more likely to actually show up.
