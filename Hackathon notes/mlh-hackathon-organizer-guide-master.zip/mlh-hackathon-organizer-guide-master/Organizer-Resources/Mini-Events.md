# Hosting Mini-Events

Hosting a Mini-Event is an awesome way to give hackers a break, add a little excitement, and have some fun!

## [Cup Stacking](Cup-Stacking.md)

Cup Stacking is a famous hackathon pastime and is sure to be a hit!
