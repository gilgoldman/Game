# Send Reminders

A week before your hackathon is the perfect time to remind everyone involved about what needs to happen. Be sure

* Attendees  — Send clear directions about when and where to report. Include transportation info.

* Sponsors — Sponsors also need clear directions about when and where to report. However, they should be at your venue well before attendees.

* Volunteers and fellow organizers — confirm all volunteer sign-up and designated duties. Send clear directions about when and where to report.

* Vendors  — confirm all times, quantities, and services

* Judges and speakers

Info needed from people: name, phone number, email, school, under 18, gender, dietary restrictions, special needs, tshirt size.