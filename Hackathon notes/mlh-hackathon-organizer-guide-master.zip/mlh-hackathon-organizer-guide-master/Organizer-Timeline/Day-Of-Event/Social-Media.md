# Run Social Media

<iframe width="640" height="360" src="https://www.youtube.com/embed/c8gqQZbJH88" frameborder="0" allowfullscreen="allowfullscreen"></iframe>

On the day of the hackathon, social media will play a critical role in communicating hackathon news and schedule updates to attendees. Make sure to designate ONE channel of communication for all updates so every attendee knows where to find important info.

* Regular tweets

* Updates to the FB invite if necessary