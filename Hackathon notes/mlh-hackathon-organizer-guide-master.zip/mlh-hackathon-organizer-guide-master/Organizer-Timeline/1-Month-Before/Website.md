# Update Website With Final Info

Ideally, you’ve been updating your site on a rolling basis as more information and sponsorships are finalized. About a month before, you want to

* Schedule

* Set up single channel of communication for day-of updates

* Survey:

  * Name

  * Email

  * Phone number

  * Dietary restrictions

  * T-shirt size

  * Will they need charter bus or travel reimbursement (does this jibe with transportation timeline?)

  * Liability waiver