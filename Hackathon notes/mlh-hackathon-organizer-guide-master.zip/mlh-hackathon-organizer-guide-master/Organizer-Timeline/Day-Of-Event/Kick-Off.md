# Kick Off Your Hackathon

<iframe width="640" height="360" src="https://www.youtube.com/embed/7CwBvQ1wjZU" frameborder="0" allowfullscreen="allowfullscreen"></iframe>

* Checking in guests

* Greeting and directing attendees

* Running social media

* Setting out food

* Managing transportation

* Guiding and attending to sponsors and press

* Running AV

* Restocking supplies and picking up garbage

## MLH Tips

* When setting up, [position the sponsor tables next to the hackers. Having the mentors literally next to the hackers makes it really easy for people to ask them for help and for the sponsors to feel as if they are part of the event](http://news.mlh.io/how-to-throw-an-epic-hackathon-07-07-2014).